import React, { useState, useEffect } from "react";
import "./App.css";

function hideDash() {
  var x = document.getElementById("dashboard");
  x.style.display = "none";
  var y = document.getElementById("security");
  y.style.display = "block";
}
function hideFunction() {
  var x = document.getElementById("security");
  x.style.display = "none";
  var y = document.getElementById("dashboard");
  y.style.display = "block";
}

function App() {
  const [currentAlarm, setAlarm] = useState(0);
  const [currentTime, setTime] = useState(0);
  const [currentHumidity, setHumidity] = useState(0);
  const [currentTemp, setTemp] = useState(0);
  const [currentAlrmPg, setAlrmPg] = useState(0);

  useEffect(() => {
    fetch("/api/time_page")
      .then((response) => response.json())
      .then((dataTime) => {
        setTime(dataTime.time);
        console.log("Time is: " + dataTime.time);
      });
    fetch("/api/alarm_state")
      .then((response) => response.json())
      .then((dataAlarm) => {
        setAlarm(dataAlarm.alarm);
        console.log("Alarm: " + dataAlarm.alarm);
      });
  });
  useEffect(() => {
    fetch("/api/alarm_state")
      .then((response) => response.json())
      .then((dataAlarm) => {
        setAlarm(dataAlarm.alarm);
        console.log("Alarm: " + dataAlarm.alarm);
      });
  }, []);

  useEffect(() => {
    fetch("/api/humidity")
      .then((response) => response.json())
      .then((dataHum) => {
        // console.log(data);
        console.log("Hum: " + dataHum.hum);
        setHumidity(dataHum.hum);
      });
  });
  useEffect(() => {
    fetch("/api/temperature")
      .then((response) => response.json())
      .then((dataTemp) => {
        setTemp(dataTemp.temp);
        console.log("Temp: " + dataTemp.temp);
      });
  });
  useEffect(() => {
    fetch("/api/alarm_page")
      .then((response) => response.json())
      .then((data) => {
        // console.log(data);
        console.log(data);
        setAlrmPg(data);
        if (data == "1") {
          alert("ALARM HAS BEEN TRIGGERED");
          console.log("alert");
        }
      });
  });

  return (
    <div className="App">
      <div className="bar">
        <img src="Untitled-removebg-preview.png" alt="Logo Image" />
      </div>
      <div className="navi">
        <ul>
          <li>
            <a onClick={hideFunction}>Environment Monitoring</a>
          </li>
          <li>
            <a onClick={hideDash}>Security</a>
          </li>
        </ul>
      </div>
      <div className="main1" id="dashboard">
        <div className="container" style={{ width: "40%" }}>
          <p>Temperature</p>
          <p
            style={{ color: "#3e7fc1", fontSize: "43px", textAlign: "center" }}
          >
            <span id="temperature">{currentTemp}</span>°C
          </p>
        </div>
        <div className="container" style={{ marginLeft: "20px", width: "40%" }}>
          <p>Humidity</p>
          <p
            style={{ color: "#3e7fc1", fontSize: "43px", textAlign: "center" }}
          >
            <span id="humidity">{currentHumidity}</span>%
          </p>
        </div>
        <br />
        <br />
      </div>

      <div className="main" id="security" style={{ display: "none" }}>
        <p>
          Status: <span id="status">{currentAlarm} </span>
        </p>
        <form action="/alarm_state" method="get" id="goButton">
          <input type="submit" value="ACT" id="buttongo" name="act" />
        </form>
      </div>
      <br />
      <br />
      <br />
      <div className="footer">
        <p>
          Last captured at <span id="time">{currentTime}</span> by Residential
          IOT Suite
        </p>
      </div>
    </div>
  );
}

export default App;
