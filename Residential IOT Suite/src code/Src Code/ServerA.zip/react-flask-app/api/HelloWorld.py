from flask import Flask, render_template, request
import RPi.GPIO as GPIO
import dht11
import time
import datetime
from mq import *
import sys
from gtts import gTTS
import os
#from playsound import playsound

sys.path.insert(1, '../function_tests/object_detection')
# import newObject_detection_picamera

# initialize GPIO
GPIO.setwarnings(True)
GPIO.setmode(GPIO.BOARD)

speaker_pin = 12
alarm_port = 15 # from security cam
web_port = 18 # from self

GPIO.setmode(GPIO.BOARD)
GPIO.setup(speaker_pin,GPIO.OUT)
GPIO.setup(web_port,GPIO.OUT)
GPIO.setup(alarm_port, GPIO.IN)

# read data using pin 
instance = dht11.DHT11(pin=7)
app = Flask(__name__)

hum = 0
temp = 0


botton = 'activate'

@app.route('/api/alarm_state', methods=['GET'])
def index():

    global botton

    #### SECURITY SYSTEM PART
    bottonn = request.values.get('act')
    print(botton)
    if bottonn == 'activate':
        botton = 'deactivate'
        GPIO.output(web_port, GPIO.HIGH)
    elif bottonn == 'deactivate':
        botton = 'activate'
        GPIO.output(web_port, GPIO.LOW)
        #alr = 0

    return {'alarm':botton}



@app.route('/api/time_page')
def timefunc():
    now = datetime.datetime.now()
    timeString = now.strftime("%Y-%m-%d %H:%M:%S")
    return {"time":timeString}

@app.route('/api/humidity')
def humfunc():
    global hum
    return {"hum":hum}

@app.route('/api/temperature')
def tempfunc():
    global hum, temp
    result = instance.read()
    if result.humidity != 0:
        hum = result.humidity
        temp = result.temperature
    print("The temperature is: " + str(temp))
    return {"temp":str(temp)}


btstate = False
@app.route('/api/alarm_page')
def alrfunc():
    global alarm_port, botton, btstate
    alr = GPIO.input(alarm_port)
    print(alr)
    print(botton)
    if botton == 'activate':
        btstate = False
    elif botton == 'deactivate':
        btstate = True
    if not btstate:
        alr = 0

    print(btstate)
    return str(alr)

if __name__ == '__main__':
    #hum = 0
    #temp = 0
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.jinja_env.auto_reload = True
    app.run(debug=True, port=80, host='0.0.0.0')